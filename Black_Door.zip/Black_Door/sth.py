from openai import OpenAI

client = OpenAI(
  api_key="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"
)

with open("dialog.txt", "r") as f:
  dialog = str(f)

response = client.responses.create(
  model="gpt-5-nano",
  input=dialog,
  store=True,
)

print(response.output_text);
