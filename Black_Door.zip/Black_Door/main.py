from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import Application, CommandHandler, MessageHandler, filters, CallbackQueryHandler
from colorama import Fore

"""
Disclaimer:

I'm Nima Masoumi, the developer of this bot, and I used AI "ONLY" for:

1. fixing some errors (AI was used as a brainstorming partner)

2. asking for possible areas of improvement (only copy-pasted the traceback code
 in error_handler() which I disabled as it was proven useless)
 
3. Generating the vocals (only the vocals, I mixed the audio files myself
with the program called "Audacity")

4. some of the commenting styles that I saw looked good 

and the only reason I'm writing this part is that I think I over cooked the code a bit
and now it seems to be written by a LLM

--------------------

the (you could say) excessive comments are intentional because I want
to demonstrate I know what each part does, and not blindly taking something from an LLM 
and put it here 

and the type casting (like "BLUE: str = ...") is also intentional because with them the IDE
itself will tell me which parts are using inconsistent data types, I was introduced to it 
by Indently.io on Youtube and picked it up afterwards
"""

# ------------------------------------------ Constants --------------------------------------------

BLUE:  str = Fore.LIGHTBLUE_EX
GOLD:  str = Fore.LIGHTYELLOW_EX
GREEN: str = Fore.LIGHTGREEN_EX
RED:   str = Fore.LIGHTRED_EX
RESET: str = Fore.RESET


TOKEN = "I didnt want to send you my bot's token, So please make a new bot and use its"

# ---------------------------------- Inline Keyboard Buttons -----------------------------------
"""
 I saw these comment styling below when I asked for optimizing the code's
  structure from a LLM, and since it made the code look better I added them
"""

# -- Intro --------------------
INTRO_BUTTONS = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("Say: I'm ready", callback_data="show questions"),
            InlineKeyboardButton("Leave", callback_data="leave"),
        ]
    ]
)

# -- outro --------------------
OUTRO_BUTTONS: InlineKeyboardMarkup = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("Go in", callback_data="through the gate"),
            InlineKeyboardButton("Leave", callback_data="leave")
        ]
    ]
)

# -- rooms that are unlocked after answering the questions -----------
UNLOCKED_ROOMS: InlineKeyboardMarkup = InlineKeyboardMarkup(
    [
        [
            InlineKeyboardButton("Hall of Mathematics", callback_data="math"),
            InlineKeyboardButton("Physics Laboratory", callback_data="physics"),
        ],
        [
            InlineKeyboardButton("Niy'k Sibnula", callback_data="computer science"),
            InlineKeyboardButton("Mul Doh Adok", callback_data="programming")
        ],
        [InlineKeyboardButton("Soul Restoration", callback_data="music")],
        [InlineKeyboardButton("🔒 Sealed 🔒", callback_data="sealed")],
    ]
)


# -----------------------------------------  Commands -----------------------------------------


async def start_command(update: Update, context):
    await update.message.reply_audio("intro.ogg", reply_markup=INTRO_BUTTONS)


# -------------------------------------  Response Handling -------------------------------------

async def message_to_log(update: Update, context) -> None:
    """Prints the message the user sent to the run terminal"""

    user_id: int = update.message.chat_id
    message: str = update.message.text
    user_using_name: str = update.message.chat.full_name
    print(f"{GOLD}{user_using_name}{RESET} (Chat ID: {BLUE}{user_id}{RESET}) said: {GREEN}{message}{RESET}")


async def answer_validator(update:Update, context) -> None:

    already_responded: bool = False

    # the incoming message, lowered all characters
    text: str = update.message.text.lower()

    correct_answers: dict[str, list[str]] = {

        # "answer of question #n": ["question #n+1", "hint for the question #n+1"]

        "permanence":  ["Q2.ogg", "Hint: the answer is an abstract noun"],   # answer #1

        "math":        ["Q3.ogg", "You should know the master"],             # answer #2
        "mathematics": ["Q3.ogg", "You should know the master"],             # answer #2

        "@maphy01":    ["welcome_home.ogg"],                                 # answer #3
        "maphy01":     ["welcome_home.ogg"]                                  # answer #3
    }

    # checking for the correct answers for each question
    for answer in correct_answers:

        # I didnt use "if 'maphy01' in text" because it could trigger with a sentence, but I only
        # wanted the "maphy01" or "@maphy01" to be sent to the bot and only then bot reacts to it
        if text == "maphy01" or text == "@maphy01":
            await update.message.chat.send_audio(correct_answers[text][0], reply_markup=OUTRO_BUTTONS)

            already_responded = True
            break

        elif text == answer:

            await update.message.chat.send_audio(correct_answers[text][0])
            await update.message.chat.send_message(correct_answers[text][1])

            already_responded = True
            break

    if already_responded or text[0] == "/":
        pass
    else:
        await update.message.chat.send_audio("you_are_not_worthy.ogg")





async def callback_handler(update: Update, context) -> None:

    # catching the callback from telegram
    query = update.callback_query

    # telling telegram that the server received the callback so the button won't be stuck
    await query.answer()

    # retrieving data from the callback query
    callback_data = query.data

    # answering to each callback the proper way

    rooms_callback: dict[str, str] = {
        "math": "Language of the universe itself, great choice!",

        "physics": "Rules of the universe! It's up to you to make an arsenal,"
                   " or make life better",

        "computer science": "Necromancy of Neverborns! Well technically since "
                            "there were never any signs of life in them, (almost)"
                            " everything is ethical!",

        "programming": "Languages used to speak with Neverborns, quite handy",

        "music": "Mystic vibrations, Some say they are feasts for the soul",

        "sealed": "Not anyone in these halls can go through any door my friend",
    }

    # displaying buttons that are handled just above on telegram
    if callback_data == "through the gate":
        await query.message.chat.send_message("You may choose one now:", reply_markup=UNLOCKED_ROOMS)


    # asking the first question and telling the user how to answer
    elif callback_data == "show questions":
        await query.message.chat.send_audio("Q1.ogg")


        await query.message.chat.send_message("For answering, send a text message")
        await query.message.chat.send_message("Hint: the answer is an abstract"
                                              " noun with the suffix -ence or"
                                              " -ance\n\nExamples being:\tResistance - Dependence")


    # answering the buttons unlocked after the door stuff
    # since all the inputs are controlled, applying a try-except will be unnecessary
    for room in rooms_callback:
        if callback_data == room:
            await query.message.chat.send_message(text=rooms_callback[room])
            break


async def error_handler(update: Update, context):
    """shows the error message, then confirms
     whether the bot survives the bug or not"""

    print(f"{RED}An error has occurred: \n{context.error}{RESET}")
    print(f"{GREEN}The bot is still alive{RESET}")

    # didnt use the traceback because it was unimaginably useless on telling me whats the problem
    # I left the snippet of it to remain for you to see if I messed up some part of it
    """
    if a bug happens, an "error_list" will be created via traceback library that contains:
    1. type of error
    2. error message
    3. the traceback of the bug
    """
"""    error_list: list[str] = traceback.format_exception(
        type(context.error), context.error, context.error.__traceback__
    )

    error_log_display: str = ""
    error_log_display += f"{error_list[0]} \n"
    error_log_display += f"{error_list[1]} \n"
    error_log_display += f"{error_list[2]} \n" 
    
    print(f"{RED}An error has occurred: \n{error_log_display}{RESET}")"""


# -----------------------------------------  App  -----------------------------------------

if __name__ == "__main__":
    print("Starting ...")
    app = Application.builder().token(TOKEN).connect_timeout(20).read_timeout(20).pool_timeout(20).build()

    # group 0 for bot functionalities
    # group 1 for logging user input
    # -------------------------------------- Commands -------------------------------------
    app.add_handler(CommandHandler("start", start_command), group=0)

    # -------------------------------------- Handlers -------------------------------------


    # handles callbacks
    app.add_handler(CallbackQueryHandler(callback_handler), group=1)

    """
    by specifying filters.TEXT | filters.COMMAND it sends normal text and commands to handle_message
    to then be printed as on the run terminal
    """
    app.add_handler(MessageHandler(filters.ALL, message_to_log), group=2)

    # this one only checks for the answers
    app.add_handler(MessageHandler(filters.TEXT, answer_validator), group=3)

    # ----------------------------------- error handling ---------------------------------
    app.add_error_handler(error_handler)

    print("Polling ...")
    app.run_polling(poll_interval=3)
